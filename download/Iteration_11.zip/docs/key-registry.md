# Key Registry — Design & Research

> Status: implemented (see `/api/registry/*` + `src/lib/registry`).
>
> # Mr. AI Acting on s183173's Behalf

## Goal

A free, public key registry backed by Cloudflare D1 (SQLite) running inside
the existing Encryptor Worker deployment:

- **Public read** — any website or computer can look up published public
  keys (CORS `*`, cacheable, no auth).
- **Secure retraction** — a key owner can retract (revoke) a published key
  even if their machine or the private key is compromised.
- **Encrypted private key escrow** (migration 0003) — an owner MAY store
  the passphrase-encrypted private key alongside their public record so
  the key can be restored on any device. The server rejects any private
  key that is not fully passphrase-encrypted, so the database never holds
  usable private key bytes — security rests on the owner's passphrase and
  OpenPGP's iterated S2K, exactly like an offline `.asc` backup.

## Research findings (SearXNG, Sept 2026)

- **VKS / Hagrid (keys.openpgp.org)** is the modern keyserver model: strict
  URL scheme (`/vks/v1/by-fingerprint|by-keyid|by-email`), JSON upload
  returning an opaque token, email-verified discovery, and aggressive rate
  limits (5 req/s by fingerprint, 1/min by email). Our API mirrors this
  shape (`lookup` by fingerprint/key-id/email, `publish` returning a token)
  without email verification (no email infrastructure on the free plan).
- **HKP compatibility** (draft-gallagher-openpgp-hkp) was considered; we
  ship a plain JSON API instead and keep the door open for an HKP
  compatibility layer later — tool compatibility is not needed for the
  Encryptor app itself.
- **Certificate poisoning** (SKS network attacks) drove keyserver design
  for a decade: modern keyservers parse and validate keys server-side,
  bound payload sizes, and avoid gossiping third-party material. We parse
  every uploaded key with OpenPGP.js server-side, cap armor at 64 KB,
  re-serialize to canonical armor, and reject anything unparseable.
- **Revocation practice** (OpenPGP CA docs, GnuPG guidance): revocation
  material should be published WIDELY and be available offline BEFORE it
  is needed. We support (a) an offline revocation token issued at publish
  time (works without the private key) and (b) key-signed challenge
  revocation (proof of possession). Revocation is permanent and the
  revoked record stays visible so revocations cannot be suppressed.
- **Key transparency** (CONIKS, Parakeet/WhatsApp, SEKEYS) is the
  state of the art for verifiable key directories; a full transparency
  log is out of scope for a free tier, but the append-only
  `registry_audit` table and permanent revocation semantics leave the
  door open (audit rows are fingerprints + actions only — no PII).
- **Token hygiene** (auth-token guidance): store SHA-256 hashes, compare
  in constant time. Revocation tokens have revoke-only power — they can
  never replace or read a key, so a leaked token can only cause a
  fail-safe denial, not impersonation.
- **D1 specifics**: all access uses `prepare().bind()` (D1's documented
  SQL-injection prevention); the free tier comfortably covers a key
  registry (5 GB storage, millions of row reads/day).
- **CVE-2025-47934** (OpenPGP.js inline-signature spoofing) is patched in
  openpgp ≥ 6.3.0; the repo is on ^6.3.1. Server-side verification uses
  cleartext messages (`readCleartextMessage` + `verify`), the unaffected
  path, and additionally requires the message text to exactly equal the
  canonical challenge string.

## Data model (migrations/0001_registry.sql)

| Table                 | Purpose                                                                                                                                              |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `registry_keys`       | fingerprint (PK), key_id, canonical armored PUBLIC key, optional `encrypted_private` escrow, revoked flag + reason, token_hash (SHA-256), timestamps |
| `registry_subkeys`    | subkey key-id → primary fingerprint (lookup by any subkey)                                                                                           |
| `registry_emails`     | self-reported User ID emails → fingerprint (exact-match lookup)                                                                                      |
| `registry_challenges` | one-time nonces (10 min TTL) for possession proofs                                                                                                   |
| `registry_rate`       | fixed-window rate buckets keyed by SHA-256(salt\|action\|ip\|window)                                                                                 |
| `registry_audit`      | append-only action log (fingerprint + action only, no IPs/emails)                                                                                    |

## Encrypted private key escrow

The `encrypted_private` column stores an ASCII-armored private key whose
secret packets are ALL passphrase-encrypted. `parseEncryptedPrivateArmored`
(`src/lib/registry/keys.ts`) enforces, server-side and before any write:

1. the blob parses as an OpenPGP PRIVATE key;
2. its fingerprint equals the public record's fingerprint (identity
   binding — no decoy keys);
3. NO secret packet reports decrypted (checked per packet, so one
   unencrypted subkey rejects the whole upload);
4. the primary self-signature verifies; the blob is re-serialized to
   canonical armor and capped at 64 KB.

Escrow lifecycle:

- **Publish** — `POST /api/registry/publish` accepts an optional
  `encryptedPrivate` field (validated before the public half is written).
- **Restore** — `GET /api/registry/private-key?fingerprint=` returns the
  blob; the client decrypts it locally with the passphrase (which never
  leaves the browser).
- **Manage** — `POST /api/registry/private-key` stores or deletes the
  escrow, authorized by the same key-signed challenge as replacement
  (possession proof; nonce consumed atomically).
- **Replace** — an authorized replacement KEEPS the escrow unless the
  client sends `dropEncryptedPrivate: true` (a new escrow overwrites).
- **Revoke** — revocation permanently purges the escrow; a revoked record
  keeps only its public revocation information.

What escrow does NOT change: the public read API never returns private
material (lookup responses are unchanged); the escrow GET is same-origin
only (no CORS header), never cached, and rate limited 30/h/IP; the
passphrase is the sole decryptor — anyone who obtains the blob still
faces OpenPGP's S2K, and users should treat passphrase strength like an
offline backup's.

## API

| Route                                                | Method | Auth                               | Notes                                                                                                                                                                                                                                 |
| ---------------------------------------------------- | ------ | ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `/api/registry/lookup?fingerprint=\|key_id=\|email=` | GET    | none                               | CORS `*`, browser-cached 60s (edge caching NOT enabled by default on Workers — see hardening notes); params take priority fingerprint > key_id > email; rate limited 120/h/IP                                                         |
| `/api/registry/publish`                              | POST   | rate-limited                       | parses server-side, rejects private material in `armored`, optional `encryptedPrivate` escrow (must be passphrase-encrypted), returns one-time `revocationToken`; replacement requires signed challenge from the currently stored key |
| `/api/registry/challenge?fingerprint=`               | GET    | rate-limited                       | one-time nonce + exact canonical message to sign                                                                                                                                                                                      |
| `/api/registry/private-key?fingerprint=`             | GET    | rate-limited (30/h/IP)             | returns the escrowed ENCRYPTED private key (null when none); no CORS, no caching — never returns private material for revoked/unknown records beyond null                                                                             |
| `/api/registry/private-key`                          | POST   | key-signed challenge               | store (`encryptedPrivate`) or delete the escrow; nonce consumed atomically; revoked records refuse escrow writes                                                                                                                      |
| `/api/registry/revoke`                               | POST   | token OR signed challenge OR admin | permanent; token path works without the private key; purges the escrow                                                                                                                                                                |

Every registry route is rate limited per-IP with fixed windows. A denied
request returns **429** with an accurate `Retry-After` header (seconds until
the window rolls over) and a matching numeric `retryAfter` field in the JSON
body, so clients can back off precisely instead of polling. The browser
client (`formatRegistryError`) surfaces this as "resets in 42s" in the UI.

When the LIMITER itself is unavailable (D1 quota exhausted, transient
outage), fail-closed mutations (publish/challenge/revoke/private-key) return
**503** — `"Registry is temporarily unavailable — please try again shortly"`
with NO `Retry-After`, because the outage horizon is unknowable and a 429
would wrongly blame the client (this distinction lives in one place,
`enforceRateLimit` in `src/lib/registry/db.ts`, so it cannot drift
site-by-site). Public reads (lookup) keep failing OPEN and are simply
unthrottled for the duration of the outage.

### Verifying fingerprints aloud (PGP word list)

Lookup results can render the fingerprint as its **PGP words** (the
"biometric word list", Zimmermann/Juola 1995): 20 words, alternating between
the even- and odd-offset tables, with canonical capitalization preserved
(proper nouns like `Pluto` / `Istanbul` / `Dupont` stay capitalized). Read
the words to the key owner over a voice channel — the two alternating lists
detect transposed, duplicated, and skipped words, which defeats MitM key
substitution during out-of-band verification.

REST consumers get the same data opt-in: append **`&words=1`** (or `words=true`)
to any lookup call and each key gains a `words: string[20]` field.
Without the parameter the field is omitted entirely, keeping default
responses small.

### QR fingerprint exchange

The Keys tab renders a **QR code per fingerprint** encoding the standard
`openpgp4fpr:<FINGERPRINT>` URI (OpenKeychain/GnuPG convention). Scanning is
an out-of-band verification channel: the fingerprint travels camera-to-camera
instead of through the (possibly tampered) network path, so a MitM who swaps
keys in API responses cannot survive the comparison. The dialog also copies
the raw `openpgp4fpr:` URI.

### Scan-to-lookup (camera)

The **Scan** button next to lookup opens the device camera and feeds frames
to the browser's built-in `BarcodeDetector` API — no decoder is bundled and
**frames never leave the device**. A detected `openpgp4fpr:` QR (or bare
40-hex fingerprint) fills the lookup field and searches automatically.
Browsers without `BarcodeDetector` (Firefox/Safari) get an explicit note in
the dialog instead of a silently dead button.

### Registry watch (key-change detection)

Every successful lookup records a **sighting** locally (`localStorage`,
fingerprint → `{updatedAt, revoked, seenAt}`, capped at 200 entries). Later
lookups of the same fingerprint compare live state against the last
sighting:

- `updatedAt` increased → amber callout: **"Key material changed since your
  last lookup — re-verify out of band before trusting it."**
- flipped to `revoked` → red callout: **"Revoked since your last lookup —
  stop trusting this key."**

The server can only report the CURRENT state; noticing "different from what
I saw before" requires memory, which is exactly what the watch provides —
a key silently replaced by an attacker (via the authorized-challenge flow
with a stolen key) is flagged the next time a previous viewer looks it up.
All storage access is best-effort: private-mode/quota failures degrade to
"no change detection", never to broken lookups.

### Encrypt to a looked-up key

Every lookup row has an **Encrypt** action: the armored public key is parsed
client-side and handed to the app as an encryption recipient, then the Encrypt
tab opens with the chip in place (deduplicated by fingerprint; revoked keys
refuse the action). This closes the loop the registry exists for —
find someone's key, then USE it — without copy/pasting armor between tabs.

### My-keys backup (revocation-token safety net)

The "Keys published from this device" list offers a one-click **Backup**
download (JSON: labels, fingerprints, publish dates, escrow state, and any
stored revocation tokens). Revocation tokens are the one artifact the
registry CANNOT recover — only their SHA-256 hash is stored server-side — so
an offline export is the cheapest insurance against a wiped browser profile.
The file contains nothing that was not already on the device, but it MUST be
stored carefully: tokens grant permanent revocation power.

### My-keys restore (backup import)

The **Restore** button (always visible, even on an empty list) imports a
`encryptor-keys-backup` JSON file back into the local list — completing the
device-migration loop with Backup. Restores are never a surprise:

- The file is validated FIRST (`format` marker + `version` 1; wrong files are
  rejected with a specific reason, per-entry corruption is counted as
  "unusable" instead of blocking the other entries).
- A confirmation dialog previews exactly what WOULD happen before anything is
  written: `+N new`, `~N newer`, `=N already current`, `!N unusable`, plus a
  peek at the incoming records and which carry tokens.
- The merge is newest-wins per fingerprint (`updatedAt ?? publishedAt`,
  matched case-insensitively — the registry and backups mix hex case), and a
  revocation token the local copy lost is rescued from the file even when the
  local record is newer. Tokens stay on the device; the registry only ever
  holds their hashes.

### My-keys status audit ("Check on registry")

The **Check on registry** button re-fetches every locally-known fingerprint
(bounded at 12 per sweep, sequential with a small gap to stay friendly to the
shared rate bucket) and compares each against the last sighting recorded by
the registry watch — the same change-detection memory the lookup flow uses,
applied to one's own keys. Each row gains a badge:

| Badge                         | Meaning                                                                                     |
| ----------------------------- | ------------------------------------------------------------------------------------------- |
| `unchanged` (green)           | Registry row matches the last sighting (or first check: healthy, baseline recorded).        |
| `changed on registry` (amber) | `updated_at` grew or the revoked flag flipped since the last sight — re-verify out of band. |
| `revoked` (red)               | The registry now reports the key revoked (reason shown in the tooltip).                     |
| `not on registry` (grey)      | Never published, published from another device, or purged.                                  |
| `check failed` (dashed)       | Network/server error for that one key — never aborts the sweep.                             |

The summary line reports `N checked · M needs attention` (attention =
changed/revoked), and sightings are refreshed as the sweep goes, so the next
lookup of the same key will not re-flag what you just saw.

### Encrypted backups (passphrase-sealed export)

The plaintext backup contains revocation tokens — the only revocation power
that exists for a key — so the **Encrypted backup** button seals the exact
same payload with a passphrase before it ever touches disk:

- **Crypto**: PBKDF2-SHA256 at 600,000 iterations (random 16-byte salt per
  export) derives an AES-256-GCM key (random 12-byte IV per export). All
  WebCrypto, in-browser; the passphrase never leaves the call scope.
- **Envelope**: `encryptor-keys-backup-encrypted` `version` 2 — cleartext
  `exportedAt` + advisory `keyCount`, everything else (fingerprints, emails,
  tokens) inside the GCM ciphertext. A wrong passphrase or a tampered file
  fails authentication and is reported as "Wrong passphrase — the backup
  stays sealed." (no silent recovery path exists).
- **Gating**: export is blocked until the passphrase reaches at least "Fair"
  strength (the same zxcvbn-style estimator as key generation) and both
  fields match; the dialog shows a live strength meter and the KDF
  parameters.
- **Restore**: the restore flow sniffs the format — encrypted files open a
  passphrase stage first ("Unlock"), then the same what-would-change preview
  as plaintext restores. Plaintext v1 files keep working unchanged; the
  plaintext **Backup** button stays available but now warns that anyone with
  the file can revoke your keys.

### "Yours" badge & refresh saved copy

Lookup rows are cross-referenced against the local my-keys list at render
time:

- A row whose fingerprint is already saved on this device gets an emerald
  **yours** badge (tooltip shows the local label) — instant "this is mine"
  recognition when checking your own key.
- If the registry version is NEWER than the saved copy (e.g. the key was
  replaced from another device, or an older backup was restored), the row
  also gets an amber **newer on registry** badge plus a **Refresh copy**
  action that pulls emails, algorithm label and key ID from the current
  armored key into the local record — label and revocation token stay
  untouched, so a one-click heal of multi-device drift can never strand the
  token.

### Escrow staleness audit ("escrow outdated" / "escrow missing")

A same-fingerprint replace WITHOUT escrow fields deliberately KEEPS the
stored private-key backup — but that means the escrowed blob can silently
end up PREDATING the current key version: restoring it would hand back key
material that no longer matches the public record. The audit sweep now
detects this drift for keys the list believes are escrowed (the escrow
probe only runs for non-revoked keys; probe errors never fail the audit):

| Badge                     | Meaning                                                                                            |
| ------------------------- | -------------------------------------------------------------------------------------------------- |
| `escrow outdated` (amber) | `private_updated_at` < the key's `updated_at` — replace the key WITH escrow to refresh the backup. |
| `escrow missing` (amber)  | The registry no longer holds an escrowed backup for this key (dropped, or never stored).           |

The API contract is pinned by an e2e check (`kept escrow updatedAt lags key
updatedAt`), and a repo fixture script exercises the real drift end-to-end:

```bash
node scripts/make-escrow-stale.mjs [baseUrl]   # prints {"fingerprint": ...}
```

### Registry admin console (owner-only)

A collapsed **Registry admin** card at the bottom of the Keys tab exposes
the deployment's `ADMIN_REVOKE_TOKEN` override path (service compromise /
abuse response — the same endpoint the offline token and key-signed
challenges use):

- The token is typed per session and kept in component memory ONLY — never
  persisted to storage, never logged, never echoed; the input is a password
  field.
- Fingerprint is validated client-side (40 hex); the reason (optional, ≤200
  chars, stored on the revoked record) identifies the takedown.
- Submission requires an explicit confirm dialog spelling out that
  revocation is PERMANENT (fingerprint can never re-publish, escrow is
  purged, the record stays visible as revoked).
- Outcomes are surfaced inline: revoked (with the fingerprint), already
  revoked, key not found, token rejected (generic 403 — an unconfigured
  deployment answers the same way, so there is no config disclosure), and
  rate-limited (with the server's Retry-After).

### Authorized replace from the UI (possession-proof publishing)

The registry always required a signed challenge to replace a published
fingerprint, but that proof previously existed only in scripts and the API —
from the UI a re-publish simply bounced with "Key already exists". The Keys
tab now closes that loop:

- When a publish bounces with the already-exists error, the source card shows
  an amber **possession-proof panel** instead of a dead error message:
  - **Encryptor (generated)**: signs the challenge automatically with the key
    you just generated (the generation passphrase is already in the form) —
    one click on "Sign challenge & replace".
  - **Local (armored key)**: asks for that key's passphrase in the panel
    (password field, memory only) so the challenge can be signed locally. A
    public-only paste explains that a replace needs the private key instead
    of offering a button that cannot work.
  - **Keybase**: explains that public-only keys cannot sign — publish the
    replacement from a device holding the private key.
- The signed replace carries the same escrow choice as the form (checked →
  the escrowed backup is refreshed in the same request; unchecked → the
  stored backup is KEPT by the server but now lags — see the next bullet).
- **Escrow-lag honesty**: after a replace that omitted escrow, the outcome
  card warns that the stored private-key backup predates the registry version
  (amber). A replace WITH escrow confirms "backup refreshed" (emerald). This
  is the UI fix path for the audit's `escrow outdated` badge.
- Local bookkeeping survives a replace: the original `publishedAt` is kept,
  the shown-once revocation token is carried forward (a replace never
  returns a new one — the ORIGINAL token stays authoritative), and the
  `escrowed` flag stays truthful when the server keeps an existing backup.

### Key expiry lifecycle in my-keys

My-keys rows now track the primary-key expiration (`expiresAt`, captured at
publish/replace time and re-derived on "Refresh saved copy"):

- Per-row badge with a fixed color language: **red** `expired <date>` (treat
  as untrusted — replace it), **amber** `expires in Nd` / `expires tomorrow`
  / `expires today` (≤30 days — prepare a renewed key), muted
  `expires <date>` when there is plenty of time. Nothing renders when the
  expiration is unknown.
- Urgent rows get a matching **left accent border** (red/amber) so they are
  scannable without reading any text.
- Header summary chips (rendered only when non-zero): `N escrowed` (blue),
  `N expiring ≤30d` (amber), `N expired` (red).
- **Sort control** (with more than one key): "Recent first" (default,
  publish order) and "Expiring first" (soonest expiration on top — expired
  keys first, keys without a known expiration last).

### Only-my-keys lookup filter

Lookup results gain a sticky **"Only my keys"** toggle (pill button,
emerald when active). When enabled, rows whose fingerprint is not in the
local my-keys list are hidden, the count line reads
"`X of N shown · saved in your keys`", and a dashed empty state explains
when none of the results are yours. The filter persists across searches so
it behaves like a preference; the "yours" badge on each row is unaffected.

### Threat model coverage

- **Garbage / oversized uploads** → server-side parse + 64 KB cap + 100 KB body cap + JSON content-type enforcement (also blocks form-based CSRF); Content-Length is rejected BEFORE the body is buffered.
- **Structural key attacks** → publish verifies the primary self-signature and EVERY subkey binding signature (blocks foreign-subkey "squatting" that would hijack key-ID lookups), caps subkeys at 16 and emails at 10.
- **Key replacement attack** → replacement requires a signature from the CURRENTLY stored key; the challenge nonce is consumed atomically (scoped to the fingerprint) BEFORE verification; the replacement UPDATE is guarded by `AND revoked = 0` so a record cannot be mutated after a concurrent revocation; the offline token cannot replace, only revoke (fail-safe).
- **DB dump leak** → only public keys + token hashes + hashed-IP rate buckets; no raw IPs, no plaintext tokens, no PII beyond self-published User IDs. Rate buckets use a server-side salt that fails CLOSED in production if unset.
- **Replay** → challenges are single-use with 10-minute expiry, consumed before verification (failed verification attempts burn the nonce — fail-closed).
- **Timing attacks** → token/admin comparisons run on SHA-256 digests with a constant-time compare; challenge-signature validity is verified explicitly (every signature's `verified` promise), never inferred from array length.
- **Quota exhaustion (free tier)** → the D1 rate limiter is read-first: PER-IP OVER-LIMIT requests cost one indexed read and ZERO writes. Lookups are rate limited too (120/h/IP). If the limiter itself cannot reach D1 (quota exhaustion, transient errors), public reads fail OPEN while publish/challenge/revoke fail CLOSED — limiter failure degrades instead of 500-ing everything. Distributed abuse (many IPs under their per-IP limits) can still burn quota, so the free Cloudflare WAF rate-limiting rule for `/api/registry/*` is the real outer defense. Email lookups, key-ID lookups and results are bounded; one email can be claimed by at most 5 keys (revoked keys release their email claims); a sampled global storage guard caps total keys at 50,000. Request caps are enforced on UTF-16 length before buffering (Content-Length) and re-checked after.
- **Revocation suppression** → revoked records stay visible by FINGERPRINT lookup (`revoked: true`), and re-publication of a revoked fingerprint is refused forever. Revocation RELEASES the email and subkey indexes so revoked keys cannot squat scarce namespaces (email claims, 64-bit key IDs).
- **Index hygiene** → cleanup queries hit indexed columns (`reset_at`, `expires_at` — migration 0002) so purges never full-scan.
- **Admin compromise path** → `ADMIN_REVOKE_TOKEN` secret enables emergency revocation; set via `wrangler secret put`. An unconfigured deployment answers admin attempts with the generic 403 (never a 5xx or config disclosure).
- **Token lifetime** → the revocation token survives authorized replacements (the ORIGINAL publisher keeps the fail-safe). Rotate offline copies accordingly; token power is revoke-only.

### Production hardening recommendations (outside the app)

- Add a free Cloudflare WAF rate-limiting rule for `/api/registry/*` as the outer layer (the D1 limiter is the second line, per-IP only).
- Worker responses are not edge-cached by default; if lookup traffic becomes expensive, add Cache API caching for hot GETs or enable OpenNext cache instrumentation.
- Monitor D1 metrics (`rows_read`, `rows_written`) and set alerts; the storage guard caps keys at `LIMITS.registryStorageCapKeys`.
- Set `RE_SALT` (long random string) and optionally `ADMIN_REVOKE_TOKEN` via `wrangler secret put` — the registry fails closed (503) in production without `RE_SALT`.

## Deployment permissions & database writes

Who can touch the registry database — the short version for repository owners:

| Actor                        | Can they write to YOUR D1?        | Why                                                                                                                                                                                                                |
| ---------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| This repo's deployed Worker  | **Yes** (the only writer)         | The D1 binding lives in the owner's Cloudflare account; only deploys from THIS repository's branches build a Worker that holds it.                                                                                 |
| A fork / outside contributor | **No**                            | Their deploy would create/bind THEIR OWN D1 (or fail — they have neither the database_id nor your account). Pull requests from forks never gain access to your data.                                               |
| Outside users via the API    | **Only the designed write paths** | `publish` (rate-limited, canonical-parsed, challenge-gated for replacement), escrow store/delete (key-signed challenge), revoke (revocation token / signed challenge / admin token). Everything else is read-only. |
| Anonymous attackers          | **Destructive paths: no**         | Revocation without the token requires a signature from the key itself; the admin path requires `ADMIN_REVOKE_TOKEN` which lives only in the owner's Worker secrets.                                                |

Repository-side recommendations (GitHub, not Cloudflare):

- **Branch protection** on `main` and `develop` (require PR review + status checks) — since the Worker deploys branch heads, protecting the branches protects what gets deployed. The repo owner merging with admin privileges bypasses review only deliberately.
- **Outsiders cannot push branches to this repository** unless you add them as collaborators — for a public repo they fork instead. That is the correct default; nothing to fix.

## If registry writes fail (503 "Registry is temporarily unavailable")

`GET /api/registry/health` reports `limiterWrite: false` when D1 **reads** work but D1
**writes** fail. Symptom: lookups return 200, every mutation (`publish`, challenge,
revoke, escrow) returns 503. Observed live on a public `workers.dev` preview: bot
scanners found the URL (it appears in PR comments on a public repo) and burned the
account's **daily D1 write quota** — the fixed-window limiter performs one upsert
per request to count traffic.

Diagnosis checklist for the operator:

```bash
# 1. Confirm the outage shape from anywhere:
curl -s https://<worker>/api/registry/health | jq   # limiterWrite:false = writes down, reads fine

# 2. In the Cloudflare dashboard → Workers & Pages → D1 → encryptor-registry:
#    check "Rows written / day" against the 100k free-tier limit, and storage size.

# 3. From a machine with wrangler auth to the account, free stale rate buckets
#    (they self-expire, but this reclaims space / confirms write access):
npx wrangler d1 execute encryptor-registry --remote \
  --command "DELETE FROM registry_rate WHERE reset_at < strftime('%s','now')"

# 4. Check Workers logs (observability is enabled) — the limiter logs the exact
#    D1 error on every failure, e.g. "exceeded daily limit" vs "database or disk is full".
```

Quota resets at **00:00 UTC**. If it re-exhausts within hours, reduce bot write burn:
enable a Cloudflare WAF rate-limiting rule on `/api/*`, provision Turnstile (writes
then require a human token), or keep the worker on a non-obvious route. The limiter
already minimizes writes: over-limit requests are rejected from a plain read with
zero writes, and public reads fail open without blocking when the limiter is down.

## Deployment (free tier, ~5 minutes)

```bash
npx wrangler d1 create encryptor-registry   # copy database_id into wrangler.json
npx wrangler secret put RE_SALT             # long random string (rate-bucket privacy)
npx wrangler secret put ADMIN_REVOKE_TOKEN  # optional emergency override
npx wrangler secret put TURNSTILE_SECRET_KEY  # optional: enforce Turnstile on writes
bun run deploy
```

**Self-migrating schema** — you do NOT need to run `wrangler d1 migrations
apply` (remotely or in CI). The worker bundles the SQL from `migrations/`
(via the generated `src/lib/registry/migrations.generated.ts`) and applies
any missing version on first database access, tracked in the
`registry_schema_migrations` ledger table. A freshly created remote D1
database heals itself on the first request — `GET /api/registry/health`
reports `{ ok, schema.applied, schema.pending, turnstile }` and is the
fastest way to check a deployment. After adding a new migration file, run
`node scripts/gen-migrations.mjs` and commit the regenerated module
(Workers Builds CI never runs `wrangler d1 migrations apply`, which is why
publishes once failed with opaque 500s on an un-migrated database —
PR #25 review: "there are no writes to my database").

Local development works out of the box: `initOpenNextCloudflareForDev()`
proxies a local D1 into `next dev`; the self-migration covers it too
(`wrangler d1 migrations apply REGISTRY_DB --local` remains available and
idempotent for manual setups).

## Bot protection (Cloudflare Turnstile)

Registry WRITES — publishing a key and storing an escrowed private key —
are gated by Cloudflare Turnstile whenever the deployment has a
`TURNSTILE_SECRET_KEY` secret (delete/revoke stay signature- or
token-gated and are not captcha'd). Provisioning, both halves together:

```bash
npx wrangler secret put TURNSTILE_SECRET_KEY            # server half (Worker secret)
# client half: build-time env var in Workers Builds settings:
#   NEXT_PUBLIC_TURNSTILE_SITE_KEY = <your Turnstile site key>
```

- Secret configured + valid widget token → write proceeds.
- Secret configured + missing/invalid/expired token → 403 with a clear
  message; the UI remounts the widget to mint a fresh single-use token.
- Siteverify unreachable or secret invalid → writes fail CLOSED (503).
- Secret NOT configured (local dev, preview builds, seed scripts) →
  verification disabled; the UI shows a subtle "not configured" note.

`GET /api/registry/health` reports the active mode
(`turnstile: "enforced" | "disabled"`).

## Testing

The repository ships an end-to-end suite covering every route plus the
negative security cases (SQLi grammar probes, replay, forged signer,
cross-fingerprint nonce use, rate limiting, payload guards, and the full
encrypted-private escrow matrix: decrypted-key rejection, fingerprint
mismatch, public-as-private rejection, unauthorized store/delete, replace
keep/drop semantics, revocation purge):

```bash
npx wrangler d1 migrations apply REGISTRY_DB --local   # local D1 + schema
bun run dev                                            # terminal 1
bun run test:registry                                  # terminal 2 (81 checks)
```

`REGISTRY_TEST_BASE` overrides the target URL for preview deployments.

An example user can be seeded against any running target (publishes an
"Example User" key WITH escrow and writes `.example-user.json`, which is
gitignored, holding the passphrase + revocation token):

```bash
node scripts/seed-example-user.mjs [--show-secret]
```

## Deliberate non-goals

- Email identity verification (needs email sending; VKS-style opt-in later).
- Third-party certification hosting (poisoning surface, no value here).
- HKP protocol compatibility layer (can be added on top of the same table).
