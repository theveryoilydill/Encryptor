"use client";

import { useCallback, useMemo, useState } from "react";
import { TriangleAlert } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { RecipientPicker } from "@/components/pgp/RecipientPicker";
import {
	AttachmentList,
	CopyButton,
	DownloadButton,
	ErrorBanner,
	InputSizeCounter,
	OutputBlock,
} from "@/components/pgp/shared";
import { MessageEditor } from "@/components/pgp/MessageEditor";
import type { PrivateKeyConfig, Recipient } from "@/components/pgp/contracts";
import { encryptAndSign, encryptMessage } from "@/lib/pgp/pgp";
import { sealForConfig } from "@/lib/pgp/pq";
import {
	buildPlaintextForEncryption,
	formatFileSize,
	readFileAsBase64,
	type EnvelopeFile,
} from "@/lib/pgp/envelope";
import { LIMITS } from "@/lib/constants";
import type { AppSettings } from "@/lib/pgp/settings";
import { InputHint, detectPgpBlock } from "@/components/pgp/InputHint";
import { getKeyExpiryStatus, parseLooseDate } from "@/lib/pgp/key-details";

export function EncryptTab({
	privateKey,
	recipients,
	setRecipients,
	includeSelf,
	onIncludeSelfChange,
	requestDecryptedKey,
	settings,
}: {
	privateKey: PrivateKeyConfig | null;
	recipients: Recipient[];
	setRecipients: (updater: (prev: Recipient[]) => Recipient[]) => void;
	includeSelf: boolean;
	onIncludeSelfChange: (v: boolean) => void;
	requestDecryptedKey: () => Promise<{ key: OpenPGP.PrivateKey; passphrase: string | null }>;
	/** App preferences (compression + editor style) — owned by PgpApp so a
	 *  settings change re-renders the open tab immediately. */
	settings: AppSettings;
}) {
	const [plaintext, setPlaintext] = useState("");
	const [attachments, setAttachments] = useState<EnvelopeFile[]>([]);
	const [output, setOutput] = useState("");
	// Quantum-sealed copy of the LAST output (settings.pqSealedCopy + a key
	// with a quantum-seal pair): an ML-KEM-768 outer layer only the owner
	// can open. Empty string = no sealed copy for the current output.
	const [sealedCopy, setSealedCopy] = useState("");
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState<string | null>(null);
	// Drag & drop depth counter (avoids flicker when crossing child elements).
	const [dragDepth, setDragDepth] = useState(0);
	// Smart-input hint dismissal, keyed to the exact message content: clearing
	// the textarea (or typing different content) re-arms the hint without
	// needing a state-reset effect.
	const [hintDismissedFor, setHintDismissedFor] = useState<string | null>(null);

	// Expiry pre-flight (R8): recipients whose key has an expired PRIMARY key.
	// Same detection the recipient chips' "Expired" badge uses
	// (getKeyExpiryStatus), so the banner and the badge can never disagree.
	// Deliberately NON-blocking: openpgp.js can still succeed when only the
	// primary is expired but a subkey remains valid — the banner warns, the
	// catch below maps the genuine failures to friendly guidance.
	const expiredRecipients = useMemo(
		() =>
			recipients.filter(
				(r) =>
					typeof r.expiresAt === "number" &&
					getKeyExpiryStatus(new Date(r.expiresAt))?.status === "expired",
			),
		[recipients],
	);

	// Derive the user's own public key from the configured private key.
	// Shown as a recipient chip when "Include me" is checked.
	const selfRecipient = useMemo<Recipient | null>(() => {
		if (!privateKey) return null;
		const info = privateKey.info;
		return {
			source: "local",
			label:
				privateKey.source === "keybase"
					? `@${privateKey.username} (you)`
					: `${privateKey.label} (you)`,
			armored: "", // not needed — we'll inject it directly in handleEncrypt
			fingerprint: info.fingerprint,
			keyID: info.keyID,
			algorithm: info.algorithm,
			expiresAt:
				// parseLooseDate (key-details.ts): the persisted config's
				// expirationTime is a Date right after configure but an ISO STRING
				// after a localStorage reload round-trip — calling .getTime()
				// directly on the string crashed the whole tab on load (R11 fix).
				// It also rejects non-Date/number garbage; a fresh Infinity (never
				// expiring) isn't a string/Date → null, matching the never-expires
				// posture of every other expiresAt consumer.
				parseLooseDate(info.expirationTime)?.getTime() ?? null,
		};
	}, [privateKey]);

	/** Read + store files, returning the stored entries (with unique names).
	 *  Shared by the add-files button/drop and the editor's image paste. */
	const addFilesReturning = useCallback(
		async (fileList: FileList | File[]): Promise<EnvelopeFile[]> => {
			const files = Array.from(fileList);
			const newOnes: EnvelopeFile[] = [];
			let sizeError: string | null = null;
			for (const f of files) {
				if (f.size > LIMITS.maxFileBytes) {
					sizeError = `"${f.name}" is ${formatFileSize(f.size)} — max ${LIMITS.maxFileLabel} per file.`;
					continue;
				}
				try {
					const data = await readFileAsBase64(f);
					newOnes.push({
						name: f.name || "unnamed",
						type: f.type || "application/octet-stream",
						data,
						size: f.size,
					});
				} catch (e) {
					sizeError = `Failed to read "${f.name}": ${(e as Error).message}`;
				}
			}
			if (newOnes.length > 0) {
				setAttachments((prev) => {
					// Deduplicate names so inline image markers always reference the
					// right attachment (same rule the old paste path used).
					const usedNames = new Set(prev.map((a) => a.name));
					for (const n of newOnes) {
						if (!usedNames.has(n.name)) {
							usedNames.add(n.name);
							continue;
						}
						const dot = n.name.lastIndexOf(".");
						let counter = 1;
						let unique = n.name;
						while (usedNames.has(unique)) {
							unique =
								dot > 0
									? `${n.name.slice(0, dot)}-${counter}${n.name.slice(dot)}`
									: `${n.name}-${counter}`;
							counter++;
						}
						usedNames.add(unique);
						n.name = unique;
					}
					return [...prev, ...newOnes];
				});
			}
			if (sizeError) setError(sizeError);
			return newOnes;
		},
		[],
	);

	const addFiles = useCallback(
		async (fileList: FileList | File[]) => {
			setError(null);
			if (Array.from(fileList).length === 0) return;
			await addFilesReturning(fileList);
		},
		[addFilesReturning],
	);

	/** Editor paste bridge: store a pasted image (as a data URL) as an
	 *  attachment and return the stored entry so the editor can reference it
	 *  with an envelope:// marker. Sync by contract — throws on read errors. */
	const handleNewImageDataUrl = useCallback((dataUrl: string): EnvelopeFile => {
		// Parse "data:<mime>;base64,<data>".
		const match = /^data:([^;,]+);base64,([\s\S]*)$/.exec(dataUrl);
		if (!match) throw new Error("Unsupported image data URL.");
		const type = match[1];
		const data = match[2];
		const size = Math.floor(data.length * 0.75);
		if (size > LIMITS.maxFileBytes) {
			throw new Error(`Image is ${formatFileSize(size)} — max ${LIMITS.maxFileLabel}.`);
		}
		const ext = type.split("/")[1]?.replace("jpeg", "jpg") || "png";
		const stored: EnvelopeFile = {
			name: `pasted-image.${ext}`,
			type,
			data,
			size,
		};
		setAttachments((prev) => {
			const usedNames = new Set(prev.map((a) => a.name));
			if (!usedNames.has(stored.name)) return [...prev, stored];
			const dot = stored.name.lastIndexOf(".");
			let counter = 1;
			let unique = stored.name;
			while (usedNames.has(unique)) {
				unique =
					dot > 0
						? `${stored.name.slice(0, dot)}-${counter}${stored.name.slice(dot)}`
						: `${stored.name}-${counter}`;
				counter++;
			}
			usedNames.add(unique);
			return [...prev, { ...stored, name: unique }];
		});
		return stored;
	}, []);

	const handleAddFiles = useCallback(
		(files: FileList | null) => {
			if (files) void addFiles(files);
		},
		[addFiles],
	);

	const handleEncrypt = useCallback(async () => {
		setError(null);
		setOutput("");
		setSealedCopy("");
		if (!plaintext.trim() && attachments.length === 0) {
			setError("Enter a message to encrypt, or attach a file.");
			return;
		}
		const signing = settings.autoSign;
		const needsOwnKey = signing || includeSelf;
		if (needsOwnKey && !privateKey) {
			setError(
				signing
					? "Auto sign is on — configure your private key (top-right button) or turn signing off in Settings to encrypt without signing."
					: '"Include me" needs your configured key — configure it (top-right button) or untick "Include me".',
			);
			return;
		}
		// Recipient validation BEFORE the passphrase prompt (R10): openpgp would
		// surface this as a raw "no encryption keys" error mid-flight — catch it
		// early with actionable guidance instead.
		if (recipients.length === 0 && !(includeSelf && privateKey)) {
			setError(
				'No recipients — add at least one public key, or tick "Include me" so you can still decrypt what you send.',
			);
			return;
		}

		setBusy(true);
		try {
			// Request the decrypted key only when a signature or the self-copy
			// actually needs it (auto sign off + no include-me ⇒ no passphrase
			// prompt at all). The decrypted key exists only in this local
			// variable and is cleared when the function returns.
			let decryptedKey: OpenPGP.PrivateKey | null = null;
			if (needsOwnKey) {
				decryptedKey = (await requestDecryptedKey()).key;
			}

			// Build the recipient key list. If "include me" is checked, derive
			// the public key from the decrypted private key.
			const recipientKeys: string[] = recipients.map((r) => r.armored);
			if (includeSelf && decryptedKey) {
				try {
					const pubArmored = decryptedKey.toPublic().armor();
					recipientKeys.push(pubArmored);
				} catch {
					// skip self-inclusion on error
				}
			}

			// Wrap plaintext + attachments in the envelope wire format.
			const plaintextForEncryption = buildPlaintextForEncryption(plaintext, attachments);
			const compression = settings.compression === "off" ? "uncompressed" : settings.compression;

			let armored: string;
			if (signing && decryptedKey) {
				// Pass the PrivateKey object directly to avoid re-armoring +
				// re-parsing, which can lose key material for Keybase P3SKB keys.
				armored = await encryptAndSign({
					plaintext: plaintextForEncryption,
					recipientPublicKeys: recipientKeys,
					signerPrivateKey: decryptedKey,
					// User preference: compress by default, at maximum supported
					// compression; "off" maps to the explicit uncompressed preference.
					compression,
				});
			} else {
				armored = await encryptMessage({
					plaintext: plaintextForEncryption,
					recipientPublicKeys: recipientKeys,
					compression,
				});
			}

			// Quantum-sealed copy (opt-in): an ML-KEM-768 outer layer over the
			// armored output, sealed to the configured key's quantum-seal
			// public half. Needs no secret — sealing is passphrase-free.
			if (settings.pqSealedCopy && privateKey?.pq) {
				try {
					setSealedCopy(await sealForConfig(armored, privateKey.pq, privateKey.info.fingerprint));
				} catch {
					// The classical output stays usable even if the PQ layer fails.
				}
			}
			setOutput(armored);

			// The user can always decrypt their own copy (Include me) — so the
			// plaintext is deleted from the composer as soon as the ciphertext
			// exists. Only the output remains in memory.
			setPlaintext("");
			setAttachments([]);
			setHintDismissedFor(null);
		} catch (e) {
			const msg = (e as Error).message ?? String(e);
			// Expired-key failures surface as openpgp internals — translate to
			// actionable guidance (R8). Triggered e.g. when every encryption
			// subkey of a recipient is expired: "Could not find valid encryption
			// key packet in key <KEYID>: Subkey is expired".
			if (
				/could not find valid encryption key packet|subkey is expired|key is expired/i.test(msg)
			) {
				setError(
					"A recipient key is expired — OpenPGP refused to encrypt to it. Remove the expired recipient (or ask its owner for an updated public key) and encrypt again.",
				);
			} else {
				setError(msg);
			}
		} finally {
			setBusy(false);
		}
	}, [
		plaintext,
		attachments,
		recipients,
		privateKey,
		includeSelf,
		requestDecryptedKey,
		settings.autoSign,
		settings.compression,
		settings.pqSealedCopy,
	]);

	// Cheap substring detection on the MESSAGE textarea, computed during render
	// (no effect needed). Hints never appear for empty input; signed input is
	// not flagged here (signing already-encrypted input is a legitimate flow).
	// Dismissal is keyed to the message text, so clearing the field re-arms
	// the hint.
	const detectedBlock = detectPgpBlock(plaintext);
	const showEncryptHint =
		plaintext.trim() !== "" &&
		(detectedBlock === "encrypted" ||
			detectedBlock === "publickey" ||
			detectedBlock === "privatekey") &&
		hintDismissedFor !== plaintext;

	// Approximate input size for the output-block savings stat (R10): the
	// message bytes plus each attachment's original size — the same numbers
	// the envelope wire format wraps. Armor is ASCII so the output's string
	// length ≈ byte length; the comparison is an honest "did compression do
	// anything" signal, not an exact accounting (markers/base64 framing add
	// a small fixed overhead on the input side too).
	const inputBytes = useMemo(
		() =>
			new TextEncoder().encode(plaintext).length + attachments.reduce((sum, a) => sum + a.size, 0),
		[plaintext, attachments],
	);

	return (
		<section
			className="relative space-y-6"
			onKeyDown={(e) => {
				// Ctrl/Cmd+Enter runs the primary action from anywhere in the tab
				// (editor, attachment list, button). Skips while a run is in flight
				// — same guard as the button's disabled state.
				if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && e.key === "Enter") {
					e.preventDefault();
					if (!busy) void handleEncrypt();
				}
			}}
			onDragEnter={(e) => {
				if (!e.dataTransfer.types.includes("Files")) return;
				e.preventDefault();
				setDragDepth((d) => d + 1);
			}}
			onDragOver={(e) => {
				if (!e.dataTransfer.types.includes("Files")) return;
				e.preventDefault();
			}}
			onDragLeave={(e) => {
				if (!e.dataTransfer.types.includes("Files")) return;
				setDragDepth((d) => Math.max(0, d - 1));
			}}
			onDrop={(e) => {
				if (!e.dataTransfer.types.includes("Files")) return;
				e.preventDefault();
				setDragDepth(0);
				if (e.dataTransfer.files.length > 0) {
					void addFiles(e.dataTransfer.files);
				}
			}}
		>
			{dragDepth > 0 && (
				<div
					aria-hidden
					className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center rounded-xl border-2 border-dashed border-[#0055dc] bg-[#0055dc]/5 dark:border-[#5e94ff] dark:bg-[#5e94ff]/10 animate-fade-up"
				>
					<span className="rounded-lg bg-background/95 px-4 py-2 text-sm font-medium text-[#0055dc] shadow-sm dark:text-[#5e94ff]">
						Drop files to attach
					</span>
				</div>
			)}
			<RecipientPicker
				recipients={recipients}
				setRecipients={setRecipients}
				selfRecipient={selfRecipient}
				includeSelf={includeSelf}
				onIncludeSelfChange={onIncludeSelfChange}
			/>

			<div className="rounded-xl">
				<MessageEditor
					value={plaintext}
					onChange={setPlaintext}
					files={attachments}
					onNewImageDataUrl={handleNewImageDataUrl}
					editorKind={settings.markdownEditor}
					placeholder="Type the message you want to encrypt + sign…"
				/>
				{/* Char/word/size counter (visual feedback only). */}
				<InputSizeCounter text={plaintext} />
				{showEncryptHint && detectedBlock && (
					<InputHint
						tone={detectedBlock === "encrypted" ? "amber" : "info"}
						onDismiss={() => setHintDismissedFor(plaintext)}
					>
						{detectedBlock === "encrypted"
							? "This looks like an already-encrypted message. Encrypting it again is rarely what you want."
							: "This looks like a PGP key. Keys are imported in the key configuration dialog, not encrypted as messages."}
					</InputHint>
				)}
			</div>

			<AttachmentList
				attachments={attachments}
				onAddFiles={handleAddFiles}
				onRemove={(idx) => setAttachments((prev) => prev.filter((_, i) => i !== idx))}
			/>

			{/* Expiry pre-flight warning (R8): fires as soon as an expired key is
          on the recipient list — before any passphrase is requested. Amber,
          matching the own-key "expiring" banner family; non-blocking. */}
			{expiredRecipients.length > 0 && (
				<div
					role="status"
					className="animate-fade-up flex items-start gap-2.5 rounded-xl border border-amber-300/70 bg-amber-50 px-4 py-3 shadow-sm dark:border-amber-900/50 dark:bg-amber-950/30"
				>
					<TriangleAlert
						aria-hidden="true"
						className="mt-0.5 size-4 shrink-0 text-amber-600 dark:text-amber-400"
					/>
					<p className="text-xs leading-relaxed text-amber-900 dark:text-amber-200">
						<span className="font-medium">
							{expiredRecipients.length === 1
								? "A recipient key has expired."
								: `${expiredRecipients.length} recipient keys have expired.`}
						</span>{" "}
						{expiredRecipients
							.map(
								(r) => `“${r.label}” (expired ${new Date(r.expiresAt ?? 0).toLocaleDateString()})`,
							)
							.join(", ")}{" "}
						— encryption may fail. Ask the owner for an updated public key.
					</p>
				</div>
			)}

			{error && <ErrorBanner message={error} />}

			<div className="flex gap-2">
				<Button
					onClick={handleEncrypt}
					disabled={busy}
					className="bg-[#0055dc] text-white hover:bg-[#0046b8] transition-colors duration-150 press-effect"
				>
					{busy
						? "Encrypting…"
						: output
							? settings.autoSign
								? "Encrypt & sign again"
								: "Encrypt again"
							: settings.autoSign
								? "Encrypt & sign"
								: "Encrypt"}
				</Button>
			</div>

			{output && (
				<OutputBlock
					title={settings.autoSign ? "Encrypted + signed message" : "Encrypted message"}
					output={output}
					files={[]}
					// The plaintext was deleted from the composer on success —
					// only the ciphertext remains in memory, so there is no
					// preview and nothing to nuke. "Show raw text" IS the view.
					operation="encrypt"
					inputBytes={inputBytes}
					onReset={() => {
						setOutput("");
						setSealedCopy("");
						setError(null);
					}}
				/>
			)}

			{/* Quantum-sealed copy (opt-in): only produced when the key has a
            quantum-seal pair. Shown as a secondary output row with its own
            copy/download actions — it is an archive artifact, not the thing
            you send. */}
			{sealedCopy && (
				<section className="animate-fade-up space-y-2 rounded-xl border border-violet-300/60 bg-violet-50/60 p-4 shadow-sm dark:border-violet-900/50 dark:bg-violet-950/20">
					<div className="flex flex-wrap items-center justify-between gap-2">
						<div className="min-w-0">
							<p className="text-xs font-medium text-violet-900 dark:text-violet-300">
								Quantum-sealed copy (ML-KEM-768)
							</p>
							<p className="mt-0.5 text-[11px] text-muted-foreground">
								Post-quantum outer layer for your archive — even a future quantum computer
								can&apos;t open it without this device&apos;s key + passphrase.
							</p>
						</div>
						<div className="flex shrink-0 gap-2">
							<CopyButton text={sealedCopy} label="Copy" ariaLabel="Copy quantum-sealed copy" />
							<DownloadButton text={sealedCopy} title="quantum-sealed copy" />
						</div>
					</div>
					<Textarea
						readOnly
						rows={4}
						value={sealedCopy}
						className="field-sizing-fixed bg-muted/40 font-mono text-[11px]"
						aria-label="Quantum-sealed copy"
					/>
				</section>
			)}
		</section>
	);
}
